package usta.sistemas;

public class Main {

    public static void main(String[] args) {
	/* AUTHOR: Andres felipe Rodríguez Pesca
	DATE: 10/03/2020
	DESCRIPITION: This program draw a seahorse
	 */
        System.out.println("________$$$$..");
        System.out.println("______$$$$$$$$$$");
        System.out.println("______$$$$$$$$_$");
        System.out.println("_____$$$$$$$$$$$");
        System.out.println("______$$$$$$$$$$$");
        System.out.println("_____$$$$$$$_$$$$$");
        System.out.println("____$$$$$$$$_____$$$");
        System.out.println("____$$$$$$$$$_____$");
        System.out.println("____$$$$$$$$$$$");
        System.out.println("_____$$$$$$$$$$$");
        System.out.println("_____$$$$$$$$$$$$");
        System.out.println("______$$$$$$$$$$$$");
        System.out.println("_$$$$___$$$$$$$$$$");
        System.out.println("__$$$$$$$$$$$$$$$$");
        System.out.println("$$$$$$$$$$$$$$$$");
        System.out.println("__$__$$$$$$$$$");
        System.out.println("____$$$$$$$$$");
        System.out.println("____$$$$$$$$");
        System.out.println("___$$$$$$$$$____$");
        System.out.println("___$$$$$$$$$__$$_$$");
        System.out.println("____$$$$$$$$__$__$$");
        System.out.println("____$$$$$$$$_____$$");
        System.out.println("_____$$$$$$$$___$$$");
        System.out.println("_______$$$$$$$$$$$");
        System.out.println("__________$$$$$$")
        ;
    }
}
